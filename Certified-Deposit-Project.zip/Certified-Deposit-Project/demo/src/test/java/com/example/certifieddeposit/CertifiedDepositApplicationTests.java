package com.example.certifieddeposit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CertifiedDepositRestControllerTests {

	@Test
	void contextLoads() {
	}

}
