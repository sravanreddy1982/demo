package com.example.certifieddeposit.service;

import java.util.List;

import com.example.certifieddeposit.model.CdHistoryRatesDTO;
import com.example.certifieddeposit.model.CdManagerHistoryRatesDTO;
import com.example.certifieddeposit.model.CdManagerRatesDTO;
import com.example.certifieddeposit.model.CdRatesDTO;

public interface CdRatesService {
	
	public List<CdRatesDTO> getCustomerData(int zipCode);

	List<CdManagerRatesDTO> getManagerData(int zipCode);

	List<CdHistoryRatesDTO> getCustomerHistoryData(int zipCode);

	List<CdManagerHistoryRatesDTO> getManagerHistoryData(int zipCode);

}
