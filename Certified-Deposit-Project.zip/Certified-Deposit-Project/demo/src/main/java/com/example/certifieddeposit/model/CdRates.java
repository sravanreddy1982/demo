package com.example.certifieddeposit.model;

import java.util.Date;

import org.springframework.data.cassandra.core.mapping.PrimaryKey;

import jakarta.persistence.Table;

//@Entity
//@Table(name = "CD_RATES")
@Table
public class CdRates {

	// @Id
	// @GeneratedValue(strategy = GenerationType.AUTO)
	@PrimaryKey
	private String id;
	private String termLength;
	private Double interestRate;
	private Double managerRate;
	private Double annualPercenYield;
	private Integer minDepositToOpen;
	private Integer maxDepositPermitted;
	private Integer penaltyDays;
	private Double penaltyPercentage;
	private String cdType;
	private String status;
	private Date startDate;
	private Date endDate;
	private String createdBy;
	private String updatedBy;
	private String stateCode;

	public CdRates() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTermLength() {
		return termLength;
	}

	public void setTermLength(String termLength) {
		this.termLength = termLength;
	}

	public Double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}

	public Double getManagerRate() {
		return managerRate;
	}

	public void setManagerRate(Double managerRate) {
		this.managerRate = managerRate;
	}

	public Double getAnnualPercenYield() {
		return annualPercenYield;
	}

	public void setAnnualPercenYield(Double annualPercenYield) {
		this.annualPercenYield = annualPercenYield;
	}

	public Integer getMinDepositToOpen() {
		return minDepositToOpen;
	}

	public void setMinDepositToOpen(Integer minDepositToOpen) {
		this.minDepositToOpen = minDepositToOpen;
	}

	public Integer getMaxDepositPermitted() {
		return maxDepositPermitted;
	}

	public void setMaxDepositPermitted(Integer maxDepositPermitted) {
		this.maxDepositPermitted = maxDepositPermitted;
	}

	public Integer getPenaltyDays() {
		return penaltyDays;
	}

	public void setPenaltyDays(Integer penaltyDays) {
		this.penaltyDays = penaltyDays;
	}

	public Double getPenaltyPercentage() {
		return penaltyPercentage;
	}

	public void setPenaltyPercentage(Double penaltyPercentage) {
		this.penaltyPercentage = penaltyPercentage;
	}

	public String getCdType() {
		return cdType;
	}

	public void setCdType(String cdType) {
		this.cdType = cdType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	@Override
	public String toString() {
		return "CdRates [id=" + id + ", termLength=" + termLength + ", interestRate=" + interestRate + ", managerRate="
				+ managerRate + ", annualPercenYield=" + annualPercenYield + ", minDepositToOpen="
				+ minDepositToOpen + ", maxDepositPermitted=" + maxDepositPermitted + ", penaltyDays=" + penaltyDays
				+ ", penaltyPercentage=" + penaltyPercentage + ", cdType=" + cdType + ", status=" + status + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + ", stateCode=" + stateCode + "]";
	}
}
