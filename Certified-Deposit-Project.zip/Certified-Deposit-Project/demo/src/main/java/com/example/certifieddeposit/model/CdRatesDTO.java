package com.example.certifieddeposit.model;

public class CdRatesDTO {

	private String termLength;
	private Double interestRate;
	private Integer minDepositOpen;
	private Integer maxDepositPermit;

	public String getTermLength() {
		return termLength;
	}

	public void setTermLength(String termLength) {
		this.termLength = termLength;
	}

	public Double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}

	public Integer getMinDepositOpen() {
		return minDepositOpen;
	}

	public void setMinDepositOpen(Integer minDepositOpen) {
		this.minDepositOpen = minDepositOpen;
	}

	public Integer getMaxDepositPermit() {
		return maxDepositPermit;
	}

	public void setMaxDepositPermit(Integer maxDepositPermit) {
		this.maxDepositPermit = maxDepositPermit;
	}

	@Override
	public String toString() {
		return "CdRatesDTO [termLength=" + termLength + ", interestRate=" + interestRate + ", minDepositOpen="
				+ minDepositOpen + ", maxDepositPermit=" + maxDepositPermit + "]";
	}
}
