package com.example.certifieddeposit.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.example.certifieddeposit.service.CdRatesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.certifieddeposit.dao.CdArchiveRatesRepository;
import com.example.certifieddeposit.dao.CdRatesRepository;
import com.example.certifieddeposit.model.CdHistoryRatesDTO;
import com.example.certifieddeposit.model.ArchiveCdRates;
import com.example.certifieddeposit.model.CdManagerHistoryRatesDTO;
import com.example.certifieddeposit.model.CdManagerRatesDTO;
import com.example.certifieddeposit.model.CdRates;
import com.example.certifieddeposit.model.CdRatesDTO;

@Service
public class CdRatesServiceImpl implements CdRatesService {

	@Autowired
	CdRatesRepository cdRatesRepository;

	@Autowired
	CdArchiveRatesRepository cdArchiveRatesRepository;

	@Override
	public List<CdRatesDTO> getCustomerData(int zipCode) {

		List<String> customerIdList = getAllkey(zipCode);
		List<CdRates> cdRatesResponse = (List<CdRates>) cdRatesRepository.findAllById(customerIdList);
		List<CdRatesDTO> cdRatesList = new ArrayList<>();
		for (CdRates cdRates : cdRatesResponse) {
			CdRatesDTO cdRatesDTO = new CdRatesDTO();
			cdRatesDTO.setInterestRate(cdRates.getInterestRate());
			cdRatesDTO.setTermLength(cdRates.getTermLength());
			cdRatesDTO.setMinDepositOpen(cdRates.getMinDepositToOpen());
			cdRatesDTO.setMaxDepositPermit(cdRates.getMaxDepositPermitted());
			cdRatesList.add(cdRatesDTO);
		}
		return cdRatesList;
	}

	@Override
	public List<CdManagerRatesDTO> getManagerData(int zipCode) {

		List<String> managerIdList = getAllkey(zipCode);
		List<CdRates> cdRatesResponse = (List<CdRates>) cdRatesRepository.findAllById(managerIdList);
		List<CdManagerRatesDTO> cdRatesList = new ArrayList<>();
		for (CdRates cdRates : cdRatesResponse) {
			CdManagerRatesDTO cdManagerRatesDTO = new CdManagerRatesDTO();
			cdManagerRatesDTO.setManagerIntrstRate(cdRates.getManagerRate());
			cdManagerRatesDTO.setTermLength(cdRates.getTermLength());
			cdManagerRatesDTO.setMinDepositOpen(cdRates.getMinDepositToOpen());
			cdManagerRatesDTO.setMaxDepositPermit(cdRates.getMaxDepositPermitted());
			cdRatesList.add(cdManagerRatesDTO);
		}
		return cdRatesList;
	}

	@Override
	public List<CdHistoryRatesDTO> getCustomerHistoryData(int zipCode) {

		List<String> customerIdList = getAllkey(zipCode);
		List<ArchiveCdRates> cdHisRatesResponse = (List<ArchiveCdRates>) cdArchiveRatesRepository.findAllById(customerIdList);
		List<CdHistoryRatesDTO> cdHisRatesList = new ArrayList<>();
		for (ArchiveCdRates cdHisRates : cdHisRatesResponse) {
			CdHistoryRatesDTO cdHisRatesDTO = new CdHistoryRatesDTO();
			cdHisRatesDTO.setHistoryIntrstRate(cdHisRates.getInterestRate());
			cdHisRatesDTO.setTermLength(cdHisRates.getTermLength());
			cdHisRatesDTO.setMinDepositOpen(cdHisRates.getMindo());
			cdHisRatesDTO.setMaxDepositPermit(cdHisRates.getMaxdp());
			cdHisRatesList.add(cdHisRatesDTO);
		}
		return cdHisRatesList;
	}

	@Override
	public List<CdManagerHistoryRatesDTO> getManagerHistoryData(int zipCode) {

		List<String> managerIdList = getAllkey(zipCode);
		List<ArchiveCdRates> cdHisRatesResponse = (List<ArchiveCdRates>) cdArchiveRatesRepository.findAllById(managerIdList);
		List<CdManagerHistoryRatesDTO> cdHisRatesList = new ArrayList<>();
		for (ArchiveCdRates cdHisRates : cdHisRatesResponse) {
			CdManagerHistoryRatesDTO cdHisRatesDTO = new CdManagerHistoryRatesDTO();
			cdHisRatesDTO.setManagerHistoryIntrstRate(cdHisRates.getManagerRate());
			cdHisRatesDTO.setTermLength(cdHisRates.getTermLength());
			cdHisRatesDTO.setMinDepositOpen(cdHisRates.getMindo());
			cdHisRatesDTO.setMaxDepositPermit(cdHisRates.getMaxdp());
			cdHisRatesList.add(cdHisRatesDTO);
		}
		return cdHisRatesList;
	}

	public String getState(String zipCode) {

		/* Ensure param is a string to prevent unpredictable parsing results */
		if (zipCode == null) {
			return "zipCode can't be null";
		}

		/* Ensure we have exactly 5 characters to parse */
		if (zipCode.length() != 5) {

			return "Must pass a 5-digit zipcode";
		}

		/* Ensure we don't parse strings starting with 0 as octal values */
		int zipcode = Integer.parseInt(zipCode, 10);

		String st;
		String state;

		/* Code cases alphabetized by state */
		if (zipcode >= 35000 && zipcode <= 36999) {
			st = "AL";
			state = "Alabama'";
		} else if (zipcode >= 99500 && zipcode <= 99999) {
			st = "AK";
			state = "Alaska";
		} else if (zipcode >= 85000 && zipcode <= 86999) {
			st = "AZ";
			state = "Arizona";
		} else if (zipcode >= 71600 && zipcode <= 72999) {
			st = "AR";
			state = "Arkansas";
		} else if (zipcode >= 90000 && zipcode <= 96699) {
			st = "CA";
			state = "California";
		} else if (zipcode >= 80000 && zipcode <= 81999) {
			st = "CO";
			state = "Colorado";
		} else if ((zipcode >= 6000 && zipcode <= 6389) || (zipcode >= 6391 && zipcode <= 6999)) {
			st = "CT";
			state = "Connecticut";
		} else if (zipcode >= 19700 && zipcode <= 19999) {
			st = "DE";
			state = "Delaware";
		} else if (zipcode >= 32000 && zipcode <= 34999) {
			st = "FL";
			state = "Florida";
		} else if ((zipcode >= 30000 && zipcode <= 31999) || (zipcode >= 39800 && zipcode <= 39999)) {
			st = "GA";
			state = "Georgia";
		} else if (zipcode >= 96700 && zipcode <= 96999) {
			st = "HI";
			state = "Hawaii";
		} else if (zipcode >= 83200 && zipcode <= 83999 && zipcode != 83414) {
			st = "ID";
			state = "Idaho";
		} else if (zipcode >= 60000 && zipcode <= 62999) {
			st = "IL";
			state = "Illinois";
		} else if (zipcode >= 46000 && zipcode <= 47999) {
			st = "IN";
			state = "Indiana";
		} else if (zipcode >= 50000 && zipcode <= 52999) {
			st = "IA";
			state = "Iowa";
		} else if (zipcode >= 66000 && zipcode <= 67999) {
			st = "KS";
			state = "Kansas";
		} else if (zipcode >= 40000 && zipcode <= 42999) {
			st = "KY";
			state = "Kentucky";
		} else if (zipcode >= 70000 && zipcode <= 71599) {
			st = "LA";
			state = "Louisiana";
		} else if (zipcode >= 3900 && zipcode <= 4999) {
			st = "ME";
			state = "Maine";
		} else if (zipcode >= 20600 && zipcode <= 21999) {
			st = "MD";
			state = "Maryland";
		} else if ((zipcode >= 1000 && zipcode <= 2799) || (zipcode == 5501) || (zipcode == 5544)) {
			st = "MA";
			state = "Massachusetts";
		} else if (zipcode >= 48000 && zipcode <= 49999) {
			st = "MI";
			state = "Michigan";
		} else if (zipcode >= 55000 && zipcode <= 56899) {
			st = "MN";
			state = "Minnesota";
		} else if (zipcode >= 38600 && zipcode <= 39999) {
			st = "MS";
			state = "Mississippi";
		} else if (zipcode >= 63000 && zipcode <= 65999) {
			st = "MO";
			state = "Missouri";
		} else if (zipcode >= 59000 && zipcode <= 59999) {
			st = "MT";
			state = "Montana";
		} else if (zipcode >= 27000 && zipcode <= 28999) {
			st = "NC";
			state = "North Carolina";
		} else if (zipcode >= 58000 && zipcode <= 58999) {
			st = "ND";
			state = "North Dakota";
		} else if (zipcode >= 68000 && zipcode <= 69999) {
			st = "NE";
			state = "Nebraska";
		} else if (zipcode >= 88900 && zipcode <= 89999) {
			st = "NV";
			state = "Nevada";
		} else if (zipcode >= 3000 && zipcode <= 3899) {
			st = "NH";
			state = "New Hampshire";
		} else if (zipcode >= 7000 && zipcode <= 8999) {
			st = "NJ";
			state = "New Jersey";
		} else if (zipcode >= 87000 && zipcode <= 88499) {
			st = "NM";
			state = "New Mexico";
		} else if ((zipcode >= 10000 && zipcode <= 14999) || (zipcode == 6390) || (zipcode == 501)
				|| (zipcode == 544)) {
			st = "NY";
			state = "New York";
		} else if (zipcode >= 43000 && zipcode <= 45999) {
			st = "OH";
			state = "Ohio";
		} else if ((zipcode >= 73000 && zipcode <= 73199) || (zipcode >= 73400 && zipcode <= 74999)) {
			st = "OK";
			state = "Oklahoma";
		} else if (zipcode >= 97000 && zipcode <= 97999) {
			st = "OR";
			state = "Oregon";
		} else if (zipcode >= 15000 && zipcode <= 19699) {
			st = "PA";
			state = "Pennsylvania";
		} else if (zipcode >= 300 && zipcode <= 999) {
			st = "PR";
			state = "Puerto Rico";
		} else if (zipcode >= 2800 && zipcode <= 2999) {
			st = "RI";
			state = "Rhode Island";
		} else if (zipcode >= 29000 && zipcode <= 29999) {
			st = "SC";
			state = "South Carolina";
		} else if (zipcode >= 57000 && zipcode <= 57999) {
			st = "SD";
			state = "South Dakota";
		} else if (zipcode >= 37000 && zipcode <= 38599) {
			st = "TN";
			state = "Tennessee";
		} else if ((zipcode >= 75000 && zipcode <= 79999) || (zipcode >= 73301 && zipcode <= 73399)
				|| (zipcode >= 88500 && zipcode <= 88599)) {
			st = "TX";
			state = "Texas";
		} else if (zipcode >= 84000 && zipcode <= 84999) {
			st = "UT";
			state = "Utah";
		} else if (zipcode >= 5000 && zipcode <= 5999) {
			st = "VT";
			state = "Vermont";
		} else if ((zipcode >= 20100 && zipcode <= 20199) || (zipcode >= 22000 && zipcode <= 24699)
				|| (zipcode == 20598)) {
			st = "VA";
			state = "Virginia";
		} else if ((zipcode >= 20000 && zipcode <= 20099) || (zipcode >= 20200 && zipcode <= 20599)
				|| (zipcode >= 56900 && zipcode <= 56999)) {
			st = "DC";
			state = "Washington DC";
		} else if (zipcode >= 98000 && zipcode <= 99499) {
			st = "WA";
			state = "Washington";
		} else if (zipcode >= 24700 && zipcode <= 26999) {
			st = "WV";
			state = "West Virginia";
		} else if (zipcode >= 53000 && zipcode <= 54999) {
			st = "WI";
			state = "Wisconsin";
		} else if ((zipcode >= 82000 && zipcode <= 83199) || zipcode == 83414) {
			st = "WY";
			state = "Wyoming";
		} else {
			st = "none";
			state = "none";
		}
		return st;
	}

	public List<String> getAllkey(int zipCode) {

		String st = getState(String.valueOf(zipCode));
		// 20240101m1s9999CA
		String key1 = "20240101m1s9999" + st;
		String key2 = "20240101m1s24999" + st;
		String key3 = "20240101m1s49999" + st;
		String key4 = "20240101m1s100000" + st;
		String key5 = "20240101m6s9999" + st;
		String key6 = "20240101m6s24999" + st;
		String key7 = "20240101m6s49999" + st;
		String key8 = "20240101m6s100000" + st;
		String key9 = "20240101m12s9999" + st;
		String key10 = "20240101m12s24999" + st;
		String key11 = "20240101m12s49999" + st;
		String key12 = "20240101m12s100000" + st;

		List<String> ids = Arrays.asList(key1, key2, key3, key4, key5, key6, key7, key8, key9, key10, key11, key12);

		return ids;

	}
}
