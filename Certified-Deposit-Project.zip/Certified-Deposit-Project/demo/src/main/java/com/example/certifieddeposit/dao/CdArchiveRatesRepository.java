package com.example.certifieddeposit.dao;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

import com.example.certifieddeposit.model.ArchiveCdRates;

@Repository
public interface CdArchiveRatesRepository extends CassandraRepository<ArchiveCdRates, String> {

}
