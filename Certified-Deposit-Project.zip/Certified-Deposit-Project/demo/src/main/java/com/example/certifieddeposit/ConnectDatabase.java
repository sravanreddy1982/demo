package com.example.certifieddeposit;

import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.cql.ResultSet;
import com.datastax.oss.driver.api.core.cql.Row;

import java.nio.file.Paths;

public class ConnectDatabase {


    private static final String ASTRA_DB_ID = "78e1f24b-f845-4a27-b6e0-a8882172ae72";
    private static final String ASTRA_DB_SECRET = "l_FX-C8KuiybmZhPd2Z6AFUXuxUteDrfZnjd0bL.LxLrWCfr_yIgYZT,p4igQABl3v7E935X7HmJPJgLtTbZY6Hh723aiPc.ZC_JZkwG5J67xBcB.9PCK0UJn4G5l842";
    private static final String ASTRA_TOKEN = "AstraCS:lNmBmZNAwSjcFjRdAKOAbeAo:690b2d883facaa98bebe741324d82065411396b278021c7eaf6490e260868c21";
    private static final String ASTRA_KEYSPACE = "certifieddeposits_np";

    CqlSession session = null;

    public void connect() {
        session = CqlSession.builder().withCloudSecureConnectBundle(
                Paths.get("C:\\Workspace\\Certified-Deposit-Project\\demo\\src\\main\\resources\\secure-connect-certifieddeposits.zip"))
                    .withAuthCredentials(ASTRA_DB_ID, ASTRA_DB_SECRET).build();
    }

    public String getValue(int key) {

        if (session == null) {
            connect();
        }

        String value = "";
        ResultSet rs =
                session.execute("select name from certifieddeposits.test");
        Row row = rs.one();
        if (row != null) {
            value = row.getString("name");
        } else {
            System.out.println("An Error Occured");
        }

        return value;
    }


}
